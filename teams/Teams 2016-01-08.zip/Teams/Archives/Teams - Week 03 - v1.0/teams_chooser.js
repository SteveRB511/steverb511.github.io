// JavaScript Document

// TDL
// Auto populate selects
//

/////////////////////////////////////////////////
// Games List
// Reference Links
//      http://espn.go.com/nfl/schedule
//      http://espn.go.com/nfl/powerrankings
//      http://espn.go.com/nfl/picks
/////////////////////////////////////////////////

var gGameSlate   = [0];
var gWinnerGame  = "";
var gWinningTeam = "";
var gLoserGame   = "";
var gLosingTeam  = "";

/////////////////////////////////////////////////
// Returns a random integer between min (inclusive) and max (inclusive)
// Using Math.round() will give you a non-uniform distribution!
// http://stackoverflow.com/questions/1527803/generating-random-numbers-in-javascript-in-a-specific-range
/////////////////////////////////////////////////

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
	}	

/////////////////////////////////////////////////
// Setting up game slate
///////////////////////////////////////////////////

function getResults() {
	setgGameSlate();
	getWinner();
	getLoser();
	}
	
function setgGameSlate() {
	gGameSlate = document.getElementsByTagName("select");	
	}
	
function getWinner(){
	
	var k = 0;  // team prviously chosen check
	
	while( k < 1 ) {
		//get game
		gWinnerGame = getRandomInt( 1, 3 );
		
		//get winner, 0 = away, 1 = home
		var winner = getRandomInt( 0, 1 );
		
		//determine winning team
		if( winner < 1 ){ 
			winner = 2 * gWinnerGame - 1;
			}
		else {
			winner = 2 * gWinnerGame;
			}
	
		var w = winner-1;	
		gWinningTeam = gGameSlate[w].options[gGameSlate[w].selectedIndex].text;

		// determine if winning team	has been chosen before
		// window[gWinningTeam][1] uses the string result to identify the 
		// variable of the same name and then gets the win value in the 
		// variable's array
		if(window[gWinningTeam][1] < 1 ) k=1;
		}
	
	//Show winning game and team in form
	document.getElementById("WinGame").innerHTML  = gWinnerGame;
	document.getElementById("WinTeam").value      = gWinningTeam;
	
	}
	
function getLoser(){

	var k = 0; // team prviously chosen check
	
	while( k < 1 ) {
		var m = 0; //game check
		
		// Winning game and losing game should not 
		// be the same
		 do {
			gLoserGame = getRandomInt( 1, 3 );
			if( gLoserGame != gWinnerGame ) m = 1;
			} while( m < 1 )
		
		//get winner, 0 = away, 1 = home
		var loser = getRandomInt( 0, 1 );
		
		//determine losing team
		if( loser < 1 ){ 
			loser = 2 * gLoserGame - 1;
			}
		else {
			loser = 2 * gLoserGame;
			}
	
		var l = loser-1;	
		gLosingTeam = gGameSlate[l].options[gGameSlate[l].selectedIndex].text;
	
		// determine if losing team has been chosen before
		// window[gLosingTeam][1] uses the string result to identify the 
		// variable of the same name and then gets the lose value in the 
		// variable's array
		if(window[gLosingTeam][2] < 1 ) k=1;
		}
	
	//Show losing game and team in form
	document.getElementById("LoseGame").innerHTML  = gLoserGame;
	document.getElementById("LoseTeam").value      = gLosingTeam;
	
	}
	

	
	