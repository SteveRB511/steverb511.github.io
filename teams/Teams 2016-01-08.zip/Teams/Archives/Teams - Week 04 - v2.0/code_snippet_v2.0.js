// JavaScript Document

/**************************************************************

  CONSOLE CODE: Gets game list from NFL schedule page code
  and formats it as an array
  
  Based on:
  http://dangoldin.com/2013/08/26/extract-info-from-a-web-page-using-javascript/
  
 	 teams = document.getElementsByClassName("team-name")

 	 for (var i = 0; i < teams.length; i++) { 
     	 console.log( teams[i].textContent ); 
     	 }
	  
 JavaScript REGEX Search and Replace Notes
 https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions
 http://stackoverflow.com/questions/19801351/what-is-a-regular-expression-for-removing-spaces-between-uppercase-letters-but
  
  2-3 letter team codes
  Find a space followed by 2 or 3 uppercase letters = code
  
 	 if code == NYJ, replace with "Jets"
 	 if code == NYG, replace with "Giants"
 	 else delete 2-3 letters and their leading space
  
  Defining JavaScript regular expressions:
  
 	 var re = /pattern/flags; or 
 	 var re = new RegExp("pattern, flags");
  
/*************************************************************/

teams = document.getElementsByClassName("team-name")

var rexp = new RegExp( " [A-Z]{2,3}")

console.log( 'var gameList = [' );

for( var i = 0; i < teams.length; i++ ) {
  
  team = teams[i].textContent;
    
  code = rexp.exec( team );
  
  code.toString(); 
  
  if( code == " NYG" ){team = team.replace( rexp, " Giants");}
  	else if( code == " NYJ" ){team = team.replace( rexp, " Jets");}
  	else {team = team.replace( rexp, "");}
  
  if( i < teams.length-1 ){ console.log( '    "', team,'",' );} 
  else { console.log( '    "', team,'"' );}
 }

console.log( '    ];' );
 

