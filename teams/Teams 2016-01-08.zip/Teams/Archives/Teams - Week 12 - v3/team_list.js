// JavaScript Document

//Team = [chosen as winner, chosen as loser]

var Arizona       = ["Arizona",1,0];		//winner week 12
var Atlanta       = ["Atlanta",1,0]; 		//winner week 06
var Baltimore     = ["Baltimore",1,0];		//winner week 04
var Buffalo       = ["Buffalo",0,0];
var Carolina      = ["Carolina",0,1];		//						loser week 03
var Chicago       = ["Chicago",0,0];
var Cincinnati    = ["Cincinnati",0,0];
var Cleveland     = ["Cleveland",0,1];		//						loser week 04
var Dallas        = ["Dallas",0,0];
var Denver        = ["Denver",1,1];			//winner week 10		loser week 08
var Detroit       = ["Detroit",0,0];
var GreenBay      = ["Green Bay",0,0];
var Houston       = ["Houston ",0,0];
var Indianapolis  = ["Indianapolis",0,1]; 	//						loser week 06
var Jacksonville  = ["Jacksonville",1,0];	//winner week 05
var KansasCity    = ["Kansas City",1,0];	//winner week 07
var Miami         = ["Miami",1,1];			//winner week 08		loser week 09
var Minnesota     = ["Minnesota",0,0];
var NewEngland    = ["New England",0,1];	//						loser week 11
var NewOrleans    = ["New Orleans",0,0];
var NewYorkGiants = ["New York Giants",0,0];
var NewYorkJets   = ["New York Jets",0,1];	//						loser week 07
var Oakland       = ["Oakland",1,1];		//winner week 11		loser week 10
var Philadelphia  = ["Philadelphia",1,0];	//winner week 09
var Pittsburgh    = ["Pittsburgh",1,0];		//winner week 03
var SanDiego      = ["San Diego",0,0];
var SanFrancisco  = ["San Francisco",0,0];
var Seattle       = ["Seattle",0,0];
var StLouis       = ["Saint Louis",1,0];	//winner week 02
var TampaBay      = ["Tampa Bay ",0,1];		//						loser week 02
var Tennessee     = ["Tennessee",0,1];		//						loser week 12
var Washington    = ["Washington",0,1];		//						loser week 05

var teams = [
Arizona,
Atlanta,
Baltimore,
Buffalo,
Carolina,
Chicago,
Cincinnati,
Cleveland,
Dallas,
Denver,
Detroit,
GreenBay,
Houston,
Indianapolis,
Jacksonville,
KansasCity,
Miami,
Minnesota,
NewEngland,
NewOrleans,
NewYorkGiants,
NewYorkJets,
Oakland,
Philadelphia,
Pittsburgh,
SanDiego,
SanFrancisco,
Seattle,
StLouis,
TampaBay,
Tennessee,
Washington
];