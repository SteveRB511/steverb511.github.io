Final - Week 18

var rankings = [
"Panthers",
"Broncos",
"Seahawks",
"Cardinals",
"Patriots",
"Bengals",
"Steelers",
"Chiefs",
"Vikings",
"Packers",
"Redskins",
"Jets",
"Texans",
"Bills",
"Falcons",
"Raiders",
"Colts",
"Eagles",
"Saints",
"Lions",
"Dolphins",
"Rams",
"Giants",
"Buccaneers",
"Bears",
"Ravens",
"Jaguars",
"Chargers",
"49ers",
"Cowboys",
"Titans",
"Browns"
]
    7

