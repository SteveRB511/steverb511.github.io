// JavaScript Document

//Team = [chosen as winner, chosen as loser]

var Arizona       = ["Cardinals",1,0];		//winner week 12
var Atlanta       = ["Falcons",1,0]; 		//winner week 06
var Baltimore     = ["Ravens",1,0];		//winner week 04
var Buffalo       = ["Bills",1,0];		//winner week 14
var Carolina      = ["Panthers",0,1];		//						loser week 03
var Chicago       = ["Bears",0,0];
var Cincinnati    = ["Bengals",0,0];
var Cleveland     = ["Browns",0,1];		//						loser week 04
var Dallas        = ["Cowboys",0,1];		    //                      loser week 13 - Duane: default loser
var Denver        = ["Broncos",1,1];			//winner week 10		loser week 08
var Detroit       = ["Lions",0,0];
var GreenBay      = ["Packers",0,0];
var Houston       = ["Texans",0,0];
var Indianapolis  = ["Colts",0,1]; 	//						loser week 06
var Jacksonville  = ["Jaguars",1,1];	//winner week 05		loser week 14
var KansasCity    = ["Chiefs",1,0];	//winner week 07
var Miami         = ["Dolphins",1,1];			//winner week 08		loser week 09
var Minnesota     = ["Vikings",0,0];
var NewEngland    = ["Patriots",0,1];	//						loser week 11
var NewOrleans    = ["Saints",0,0];
var NewYorkGiants = ["Giants",0,0];
var NewYorkJets   = ["Jets",0,1];	//						loser week 07
var Oakland       = ["Raiders",1,1];		//winner week 11		loser week 10
var Philadelphia  = ["Eagles",1,0];	//winner week 09
var Pittsburgh    = ["Steelers",1,0];		//winner week 03
var SanDiego      = ["Chargers",0,0];
var SanFrancisco  = ["49ers",0,0];
var Seattle       = ["Seahawks",0,0];
var StLouis       = ["Rams",1,0];	//winner week 02
var TampaBay      = ["Buccaneers",0,1];		//						loser week 02
var Tennessee     = ["Titans",0,1];		//						loser week 12
var Washington    = ["Redskins",1,1];		//winner week 13		loser week 05 - Duane: default winner

var teams = [
Arizona,
Atlanta,
Baltimore,
Buffalo,
Carolina,
Chicago,
Cincinnati,
Cleveland,
Dallas,
Denver,
Detroit,
GreenBay,
Houston,
Indianapolis,
Jacksonville,
KansasCity,
Miami,
Minnesota,
NewEngland,
NewOrleans,
NewYorkGiants,
NewYorkJets,
Oakland,
Philadelphia,
Pittsburgh,
SanDiego,
SanFrancisco,
Seattle,
StLouis,
TampaBay,
Tennessee,
Washington
];